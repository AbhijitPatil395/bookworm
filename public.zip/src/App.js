import logo from './logo.svg';
import './App.css';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import Signup from './pages/Signup';
import {Container,Nav,Navbar,NavDropdown } from "react-bootstrap";
import Navigationbar from './pages/Navigationbar';
import Login from './pages/Login';
import Invoice from './pages/Invoice'
import Payment from './pages/Payment'

const Products = [
  { id: 101, title: "The Alchemist", type: "e-Book", price: 250 },
  { id: 102, title: "The Hindu", type: "e-Book", price: 350 },
  { id: 103, title: "The coaliation years", type: "e-Book", price: 450 },
  { id: 104, title: "The Turbulent years", type: "e-Book", price: 500 },
  { id: 105, title: "The Turbulent years2", type: "e-Book", price: 1000 },
  { id: 106, title: "The presediantial years", type: "e-Book", price: 2000 }]





function App() {
  
  return (
    <div className="App">

      <Router>
      <Navigationbar/>
        <Routes>
          <Route exact path="/">
            <Route index element={<Signup />}></Route>
            <Route path="/Login" element={<Login />}></Route>
            <Route path='/Invoice' element={<Invoice prod={Products}/>}></Route>
            <Route path='/Payment' element={<Payment prod={Products}/>}></Route>
            {/* <Route path='/ddd' ><Ddd/></Route> */}
          </Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
