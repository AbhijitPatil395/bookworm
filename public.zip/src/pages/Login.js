import {Form,Button,Row,Col,InputGroup, Container} from "react-bootstrap";
import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import { Formik } from "formik";
import * as yup from 'yup';
import { useParams,useNavigate } from "react-router-dom";
import { useState } from "react";
import './Signup.css';


                
function Login(){
  let navigate = useNavigate();
    const [user, setUser] = useState({});
  const handleChange = (event) => {
      const name = event.target.name;
      const value = event.target.value;
      setUser(values => ({ ...values, [name]: value }))
      
  }
  const [customer, setCustomer] = useState({});
    
  const handleSubmit = event => {
  alert("on submit signup"+ customer.first_name );
  const url = 'https://localhost:44385/api/User_Details/'+2
  const requestOptions = 
  {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user)
  };
  fetch(url, requestOptions)
      .then(response => console.log('Submitted successfully'),setCustomer(response))
      .catch(error => console.log('Form submit error: ', error))
      navigate("/Payment")
      console.log(user);
      alert("on submit signup 2"+ customer.first_name);
    };

    
        

  return (
    <div class="signup-form">
        
    <form onSubmit={handleSubmit}>
    
		<h2>Log In</h2>
		<p>Please login here!</p>
        
        <div class="form-group">
        	<input type="text" class="form-control" name="user_id" placeholder="User ID" required="required"
            onChange={handleChange}/>
        </div>
		<div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password" 
            required="required" onChange={handleChange}/>
        </div>
		<div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg">Log In</button>
        </div>
    </form>
	 <div class="hint-text">Dont have an account? <a href="#">Signup Now</a></div> 
     Customer: {customer.first_name}
</div>
      
  );
}

    
 export default Login;
