import React from 'react';
class Footer extends React.Component {
    render() {
       return (
        <div class="w3-container w3-teal w3-center w3-margin-top">
            <br/>
        <p id="contact">Contact: <a href="mailto:help.bookworm@gmail.com">help.bookworm@gmail.com</a></p>
        <p>Copyright &copy 2021 BookWorm</p>
        <p>Powered by Group 16 Invincibles SM VITA Mumbai.</p>
        <br/>
      </div>
       )
    }
 }
 export default Footer;
